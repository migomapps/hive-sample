#!python3
# -*- coding: utf-8 -*-
"""
"""
import sys, os
ROOT_PATH, FILE = os.path.split( __file__ )
#
import time, re
import urllib.parse
import webbrowser
from datetime import datetime, timedelta
from copy import copy
#
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# -----------------------------------------------------------------------
#  
# -----------------------------------------------------------------------

# wait_element
def wait_element( driver, search, type = By.CSS_SELECTOR, timeout = 10 ) :
    try :
        e = WebDriverWait( driver, timeout ).until( EC.presence_of_element_located( ( type, search ) ) )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# find_element
def find_element( elem, search, type = By.CSS_SELECTOR ) :
    try :
        e = elem.find_element( type, search )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# find_elements
def find_elements( elem, search, type = By.CSS_SELECTOR ) :
    try :
        e = elem.find_elements( type, search )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# driver_clean
def driver_clean( driver ) :
    try : driver.close()
    except : pass
    try : driver.quit()
    except : pass

# -----------------------------------------------------------------------
# result
# -----------------------------------------------------------------------
def result( item ) :
    print( item["music"] )

    # youtube play
    ids = []
    for item in item["music"]["items"] :
        ids.append( item["youtubeid"] )        
    param  = ",".join( ids )
    webbrowser.open( "http://www.youtube.com/watch_videos?video_ids={}".format( urllib.parse.quote( param ) ) )

# -----------------------------------------------------------------------
# get_body
# -----------------------------------------------------------------------
def get_body( driver, url, ct = None ) :
    ft = ct.strftime( "%Y.%m.%d" ) if ct else None

    # 게시물로 이동
    driver.get( url )

    # 이동후 목록 테이블 로딩될때 까지 대기
    tal = wait_element( driver, "#mform > table" )

    #
    if ft : # 검색할 날짜가 있을 경우
        for cnt in range( 1, 10 ) : # 순서대로 목록을 읽어서 날짜 비교
            # row
            elem = find_element( tal, "#itemList > tr:nth-child({})".format( cnt ) )

            # date
            e = find_element( elem, "td:nth-child(4)" )
            edate = copy( e.text )

            #
            if ft == edate :
                break
        else :
            raise Exception( "{} 날짜가 없습니다.".format( ft ) )
    else : #  검색할 날짜가 없을 경우 최상단 내용 추출
        for cnt in range( 1, 10 ) :
            elem = find_element( tal, "#itemList > tr:nth-child({})".format( cnt ) )

            e = find_element( elem, "td:nth-child(1)" )
            if e.text.isdigit() :
                break
        else :
            raise Exception( "항목이 없습니다." )

    #
    res = { "url" : "", "body" : "" }

    # 게시물의 URL
    e = find_element( elem, "td.subject > div > a" )
    res["url"] = copy( e.get_attribute( "href" ) )

    # 게시물로 이동
    e.click()
    e = wait_element( driver, "#contents" )

    # 게시물 내용 추출
    e = find_element( driver, "div.view_con > div.con_txt" )

    #
    res["body"] = copy( e.text )

    #
    return res

# -----------------------------------------------------------------------
# 
# -----------------------------------------------------------------------
def youtube( driver, items ) :
    ritems = []
    for item in items :
        ritem = None

        # 유뷰브로 노래 제목을 검색
        driver.get( "https://www.youtube.com/results?hl=ko&search_query={}".format( urllib.parse.quote( item ) ) )
        e = wait_element( driver, "#contents" )
        time.sleep( 5.0 )

        #
        elem = find_elements( e, "ytd-video-renderer" )
        for e in elem :
            v = find_element( e, "#video-title" )
            if not v : # 제목 체크
                print( "not found '#video-title' !!!" )
                continue

            url = v.get_attribute( "href" )
            if not url : # URL 체크
                print( "not found 'href' !!!" )
                continue

            v = urllib.parse.parse_qs( urllib.parse.urlsplit( url ).query )
            if not "v" in v and len( v["v"] ) == 0 : # 재생아이디 체크
                print( "not youtubeid !!!" )
                continue

            ritem = { "subject" : item, "youtubeid" : v["v"][0] }
            break

        #
        if ritem is None :
            print( "not found search !!! ({})".format( item["subject"] ) )
            continue
        
        #
        ritems.append( ritem )

    #
    return ritems

# -----------------------------------------------------------------------
# get_youtube
# -----------------------------------------------------------------------
def get_youtube( driver, url, ct ) :
    res = get_body( driver, url, ct )
    url, body = res["url"], res["body"]

    #
    r1 = re.compile( "M[\d ]+\)[ ]*" )
    r2 = re.compile( "\[신청.+?\]" )

    # 노래 제목 추출
    items = []
    for v in body.split( "\n" ) :
        #
        if len( v ) == 0 :
            continue

        # poem
        if v.find( "일 선곡표" ) >= 0 :
            continue

        v = r1.sub( "", v )
        v = r2.sub( "", v )

        items.append( v )

    #
    mitems = youtube( driver, items )
    return { "url" : url,  "items" : mitems }

# -----------------------------------------------------------------------
# start
# -----------------------------------------------------------------------

#
RC1 = re.compile( "(.+? <.+)\n" )
RC2 = re.compile( "[\w].+" )

#
def start( driver ) :
    # 전날 날짜 설정
    ct = datetime.now() - timedelta( days = 1 )
    ft = ct.strftime( "%Y.%m.%d" )

    #
    item = { "poem" : None, "healing" : None, "music" : None }

    # poem
    res = get_body( driver, "http://home.ebs.co.kr/poem/board/17/502629/list?hmpMnuId=101", ct )
    lst = RC1.findall( res["body"] + "\n" )
    items = []
    for v in lst :
        # 시 제목만 들어간 줄 선택
        t = RC2.match( v )
        if t :
            items.append( t.group( 0 ) )
    #
    item["poem"] = { "items" : items, "url" : res["url"] }

    # healing
    res = get_body( driver, "http://home.ebs.co.kr/poem/board/87/10080469/list?hmpMnuId=101" )
    item["healing"] = res

    # music
    res = get_youtube( driver, "http://home.ebs.co.kr/poem/board/18/502630/list?hmpMnuId=101", ct )
    item["music"] = res

    #
    result( item )

# -----------------------------------------------------------------------
# main
# -----------------------------------------------------------------------
def main() :
    drv_path = os.path.join( ROOT_PATH, "chromedriver.exe" )
    driver = webdriver.Chrome( executable_path = drv_path )

    #
    driver.delete_all_cookies()
    driver.set_page_load_timeout( 3 * 60 ) # 3 min

    #
    try :
        r = start( driver )
    except :
        driver_clean( driver )
        raise

    #
    driver_clean( driver )

# -----------------------------------------------------------------------
# __name__
# -----------------------------------------------------------------------
if __name__ == "__main__" :
    main()