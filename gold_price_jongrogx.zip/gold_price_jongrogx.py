#!python3
# -*- coding: utf-8 -*-
"""
"""
import sys, os
ROOT_PATH, FILE = os.path.split( __file__ )
from copy import copy
from datetime import datetime
#
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# -----------------------------------------------------------------------
#  
# -----------------------------------------------------------------------

# wait_element
def wait_element( driver, search, type = By.CSS_SELECTOR, timeout = 10 ) :
    try :
        e = WebDriverWait( driver, timeout ).until( EC.presence_of_element_located( ( type, search ) ) )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# find_element
def find_element( elem, search, type = By.CSS_SELECTOR ) :
    try :
        e = elem.find_element( type, search )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# find_elements
def find_elements( elem, search, type = By.CSS_SELECTOR ) :
    try :
        e = elem.find_elements( type, search )
    except ( TimeoutException, NoSuchElementException ) :
        return None
    return e

# driver_clean
def driver_clean( driver ) :
    try : driver.close()
    except : pass
    try : driver.quit()
    except : pass

# -----------------------------------------------------------------------
# result
# -----------------------------------------------------------------------
def result( items ) :
#    print( items )

    # 원하는 금값 계산하기
    g = 3 # 3돈

    for item in items :
        # 문자형태를 숫자 형태로 변환

        # 살때
        v = item["sale"]
        v = v.replace( "원", "" ).replace( ",", "" ) # '원', ',' 문자제거, 숫자만
        sale = int( v ) # 숫자형으로 변경

        # 팔때
        v = item["buy"]
        v = v.replace( "원", "" ).replace( ",", "" )
        buy = int( v )

        #
        print( "{} / 팔때 : {}원 / 살떄 : {}원".format( item["name"], sale * g, buy * g ) )

# -----------------------------------------------------------------------
# start
# -----------------------------------------------------------------------
def start( driver ) :
    driver.get( "http://www.jongrogx.com/" )

    ct = datetime.now()
    ft = ct.strftime( "%Y. %m. %d" )

    # 
    e = wait_element( driver, "#sectionMain > div > h2 > span" )
    if not e :
        raise Exception( "오늘날짜" )
    
    if ft != e.text :
        print( "not today !!!" )
        return False

    #
    elem = find_element( driver, "#sectionMain > div > div.gold_L > table > tbody" )
    if not elem :
        raise Exception( "시세 테이블" )

    #
    item = []

    for i in range( 1, 6 ) :
        #
        target = find_element( elem, "tr:nth-child({})".format( i ) )
        if not target :
            raise Exception( "시세 tr({})".format( i ) )

        #
        v = { "name" : "", "sale" : { "point" : 0, "price" : "" }, "buy" : { "point" : 0, "price" : "" } }

        e = find_element( target, "td:nth-child(1)" )
        if not e :
            raise Exception( "항목이름" )
        v["name"] = copy( e.text )

        e = find_element( target, "td:nth-child(2) > span.price" )
        if not e :
            raise Exception( "팔때 금액" )
        v["sale"] = copy( e.text )

        e = find_element( target, "td:nth-child(3) > span.price" )
        if not e :
            raise Exception( "살떄 금액" )
        v["buy"] = copy( e.text )

        item.append( v )

    #
    result( item )

# -----------------------------------------------------------------------
# main
# -----------------------------------------------------------------------
def main() :
    drv_path = os.path.join( ROOT_PATH, "chromedriver.exe" )
    driver = webdriver.Chrome( executable_path = drv_path )

    #
    driver.delete_all_cookies()
    driver.set_page_load_timeout( 3 * 60 ) # 3 min

    #
    try :
        r = start( driver )
    except :
        print( sys.exc_info() )

    #
    driver_clean( driver )

# -----------------------------------------------------------------------
# __name__
# -----------------------------------------------------------------------
if __name__ == "__main__" :
    main()
